<?php
    $connect = mysqli_connect("localhost","id21637522_tz","Saputra#123","db_university") or die("Koneksi Gagal");
?>